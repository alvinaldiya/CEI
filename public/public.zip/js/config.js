function base_url(){
    var base_url = window.location.origin;
    return base_url;
}